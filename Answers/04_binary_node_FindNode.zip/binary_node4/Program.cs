using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace binary_node4
{
    class Program
    {
        static void Main(string[] args)
        {
            // Build a test tree.
            //      Root
            //      /  \
            //     A    B
            //    / \    \
            //   C   D    E
            //           /
            //          F
            BinaryNode<string> root = new BinaryNode<string>("Root");
            BinaryNode<string> a = new BinaryNode<string>("A");
            BinaryNode<string> b = new BinaryNode<string>("B");
            BinaryNode<string> c = new BinaryNode<string>("C");
            BinaryNode<string> d = new BinaryNode<string>("D");
            BinaryNode<string> e = new BinaryNode<string>("E");
            BinaryNode<string> f = new BinaryNode<string>("F");

            root.AddLeft(a);
            root.AddRight(b);
            a.AddLeft(c);
            a.AddRight(d);
            b.AddRight(e);
            e.AddLeft(f);

            // Perform traversals.
            string result;
            result = "Preorder:      ";
            foreach (BinaryNode<string> node in root.TraversePreorder())
            {
                result += string.Format("{0} ", node.Value);
            }
            Console.WriteLine(result);

            result = "Inorder:       ";
            foreach (BinaryNode<string> node in root.TraverseInorder())
            {
                result += string.Format("{0} ", node.Value);
            }
            Console.WriteLine(result);

            result = "Postorder:     ";
            foreach (BinaryNode<string> node in root.TraversePostorder())
            {
                result += string.Format("{0} ", node.Value);
            }
            Console.WriteLine(result);

            result = "Breadth First: ";
            foreach (BinaryNode<string> node in root.TraverseBreadthFirst())
            {
                result += string.Format("{0} ", node.Value);
            }
            Console.WriteLine(result);

            Console.ReadLine();
        }

        private static void FindValue(BinaryNode<string> root, string target)
        {
            BinaryNode<string> node = root.FindNode(target);
            if (node == null)
                Console.WriteLine(string.Format("Value {0} not found", target));
            else
                Console.WriteLine(string.Format("Found {0}", node.Value));
        }
    }
}
