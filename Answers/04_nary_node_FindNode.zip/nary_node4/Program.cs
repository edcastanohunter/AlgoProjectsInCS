﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace nary_node4
{
    class Program
    {
        static void Main(string[] args)
        {
            // Build a test tree.
            //       Root
            //        |
            //     +--+--+
            //     A  B  C
            //     |     |
            //    +-+    +
            //    D E    F
            //    |      |
            //    +     +-+
            //    G     H I
            NaryNode<string> root = new NaryNode<string>("Root");
            NaryNode<string> a = new NaryNode<string>("A");
            NaryNode<string> b = new NaryNode<string>("B");
            NaryNode<string> c = new NaryNode<string>("C");
            NaryNode<string> d = new NaryNode<string>("D");
            NaryNode<string> e = new NaryNode<string>("E");
            NaryNode<string> f = new NaryNode<string>("F");
            NaryNode<string> g = new NaryNode<string>("G");
            NaryNode<string> h = new NaryNode<string>("H");
            NaryNode<string> i = new NaryNode<string>("I");

            root.AddChild(a);
            root.AddChild(b);
            root.AddChild(c);
            a.AddChild(d);
            a.AddChild(e);
            c.AddChild(f);
            d.AddChild(g);
            f.AddChild(h);
            f.AddChild(i);

            // Perform traversals.
            string result;
            result = "Preorder:      ";
            foreach (NaryNode<string> node in root.TraversePreorder())
            {
                result += string.Format("{0} ", node.Value);
            }
            Console.WriteLine(result);

            result = "Postorder:     ";
            foreach (NaryNode<string> node in root.TraversePostorder())
            {
                result += string.Format("{0} ", node.Value);
            }
            Console.WriteLine(result);

            result = "Breadth First: ";
            foreach (NaryNode<string> node in root.TraverseBreadthFirst())
            {
                result += string.Format("{0} ", node.Value);
            }
            Console.WriteLine(result);

            Console.ReadLine();
        }

        private static void FindValue(NaryNode<string> root, string target)
        {
            NaryNode<string> node = root.FindNode(target);
            if (node == null)
                Console.WriteLine(string.Format("Value {0} not found", target));
            else
                Console.WriteLine(string.Format("Found {0}", node.Value));
        }
    }
}
